<div class="medium-12 columns">
	<h3>Documents</h3>
	<div class="row">
		<div class="large-3 columns">
			<div class="row">
				<a href="#" class="medium-11 columns button secondary">
					<i class="fa fa-folder-o fa-5x"></i>Document
				</a>
			</div>
		</div>
		<div class="large-3 columns">
			<div class="row">
				<a href="#" class="medium-11 columns button secondary">
					<i class="fa fa-folder-o fa-5x"></i>Document
				</a>
			</div>
		</div>
		<div class="large-3 columns">
			<div class="row">
				<a href="#" class="medium-11 columns button secondary">
					<i class="fa fa-folder-o fa-5x"></i>Document
				</a>
			</div>
		</div>
		<div class="large-3 columns">
			<div class="row">
				<a href="#" class="medium-11 columns button secondary">
					<i class="fa fa-file-o fa-5x"></i> Fichier
				</a>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="large-3 columns">
			<div class="row">
				<a href="#" class="medium-11 columns button secondary">
					<i class="fa fa-file-o fa-5x"></i> Fichier
				</a>
			</div>
		</div>
	</div>

</div>