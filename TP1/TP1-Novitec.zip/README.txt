Ex�cuter Site/coureur_nordique.sql
Dans localhost, naviguer Site->coureur