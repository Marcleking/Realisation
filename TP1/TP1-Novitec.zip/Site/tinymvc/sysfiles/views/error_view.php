<span style="text-align: left; background-color: #fcc; border: 1px solid #600; color: #600; display: block; margin: 1em 0; padding: .33em 6px">
  <b>TinyMVC Error:</b> <?=$errors['errstr']?><br />
  <b>File:</b> <?=$errors['errfile']?><br />
  <b>Line:</b> <?=$errors['errline']?>
</span>
