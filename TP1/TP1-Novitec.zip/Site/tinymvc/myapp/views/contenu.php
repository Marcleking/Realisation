<div class="medium-9 columns panel">
	<h2><?=$_SESSION['user']->getType()?></h2>

	<div class="row">
		
	</div>
</div>