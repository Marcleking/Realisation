<div class="medium-12 columns">
	<h3>Messages</h3>
	<div class="row">
		<div class="medium-12 columns panel">
		<p>Bacon ipsum dolor sit amet kielbasa andouille meatloaf pork belly kevin. Pork strip steak kevin pork belly shoulder turducken pork chop doner spare ribs bacon drumstick. Shoulder biltong kevin, ham shank short loin prosciutto pancetta ribeye fatback pork belly jowl chicken t-bone ham hock. Tenderloin ground round kevin beef ribs t-bone pork belly. Corned beef prosciutto kielbasa t-bone.
		</p><p>
		Prosciutto kevin biltong ball tip pork chop ham hock short loin sirloin. Corned beef ribeye jerky shoulder, meatloaf drumstick rump kielbasa tongue tri-tip flank. Cow bacon meatball tenderloin frankfurter. Shankle filet mignon corned beef cow pig short ribs pastrami shank. Sirloin brisket pork, ham ham hock filet mignon tri-tip venison boudin biltong ball tip. Capicola chicken meatloaf meatball, pork beef ribs biltong ham hock filet mignon bacon shankle strip steak rump swine. Beef pig doner, jowl chuck boudin fatback prosciutto sausage shank jerky kevin.</p>
	</div>
	</div>
	<div class="row">
		<div class="medium-12 columns panel">
		<p>Meatball pork belly ground round flank cow prosciutto capicola beef ribs kevin turducken venison leberkas jerky bacon t-bone. Ball tip tail turkey t-bone fatback. Ribeye tenderloin pork turkey pastrami short loin flank, turducken swine. Turducken filet mignon ball tip cow tri-tip doner pastrami pancetta short loin turkey sausage fatback salami jerky.
		</p><p>
		Rump frankfurter shankle, pork chop cow bresaola venison pork belly chuck beef pork loin. Tail salami turducken corned beef drumstick prosciutto frankfurter shank tri-tip. Pork salami prosciutto doner. Ham bacon pig kielbasa, shank strip steak hamburger tongue jerky. Shankle rump prosciutto frankfurter kielbasa ground round biltong, tri-tip beef ribs pastrami turkey.</p>
	</div>
	</div>
	<div class="row">
		<div class="medium-12 columns panel">
		<p>Drumstick rump fatback, beef shoulder chicken filet mignon swine pork chop prosciutto spare ribs frankfurter kielbasa. Drumstick short loin bacon ham hock kielbasa jowl pig pork chop tenderloin kevin fatback beef. Strip steak pork belly pork chop short ribs turkey fatback ground round t-bone hamburger ball tip corned beef shank. Andouille pork belly flank short loin beef ribs kevin jerky chicken turkey doner meatball cow capicola fatback venison. Shankle turkey doner strip steak, meatloaf short ribs biltong turducken pig corned beef tri-tip beef ham hock venison salami. Bacon t-bone sausage, pig pastrami turkey pork chop cow salami strip steak venison tongue leberkas ball tip.</p>		
	</div>
	</div>

	<div class="row">
		<div class="medium-12 columns">
		<a href="#" class="button radius left"> Précédant</a>
		<a href="#" class="button radius right"> Suivant</a>
	</div>
	</div>
</div>